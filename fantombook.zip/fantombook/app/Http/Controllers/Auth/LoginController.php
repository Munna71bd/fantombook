<?php

namespace App\Http\Controllers\Auth;
use Socialite;
use App\Http\Controllers\Controller;
use App\Http\Controllers\HomeController;
use Illuminate\Foundation\Auth\AuthenticatesUsers;
use Auth;
use App\User;

class LoginController extends Controller
{
    /*
    |--------------------------------------------------------------------------
    | Login Controller
    |--------------------------------------------------------------------------
    |
    | This controller handles authenticating users for the application and
    | redirecting them to your home screen. The controller uses a trait
    | to conveniently provide its functionality to your applications.
    |
    */

    use AuthenticatesUsers;

    /**
     * Where to redirect users after login.
     *
     * @var string
     */
    protected $redirectTo = '/home';
    

    /**
     * Create a new controller instance.
     *
     * @return void
     */
    public function __construct()
    {
        $this->middleware('guest')->except('logout');
    }

    

/**
     * Redirect the user to the facebook authentication page.
     *
     * @return Response
     */

     public function redirectToProvider()
    {
        return Socialite::driver('facebook')->redirect();
    }
    /**
     * Obtain the user information from facebook.
     *
     * @return Response
     */

    public function handleProviderCallback()
    {
        try{
        $user = Socialite::driver('facebook')->user();
        $userinfo = Socialite::driver('facebook')->userFromToken($user->token);
    }
    catch(\Exception $e){
        return redirect('/login');
    }
    $u=User::Where('email',$user->getID())->first();
    if(!$u){
        User::Create([
            'email'=>$user->getID(),
             'name'=>$user->getName(),
             'password'=>bcrypt('1234'),
             
            ]);
    }
        if(Auth::loginUsingID($u->id)){
           session()->flash('id',$user->getID());
           session()->flash('name',$user->getName());
           session()->flash('nic',$user->getEmail());
           session()->flash('avatar',$user->getAvatar());
           
            return redirect()->intended('/home'); 
            
           
    }
}

}

