<?php

namespace App\Http\Controllers;
use Socialite;
use Illuminate\Http\Request;
use Auth;

class HomeController extends Controller
{
    /**
     * Create a new controller instance.
     *
     * @return void
     */
    public function __construct()
    {
        $this->middleware('auth');
    }

    /**
     * Show the application dashboard.
     *
     * @return \Illuminate\Http\Response
     */
    
    public function index()
    {  
        $p='http://www.facebook.com/plugins/likebox.php?href=http%3A%2F%2Fwww.facebook.com%2F'.session()->get('id').'&width=600&colorscheme=light&show_faces=true&border_color&stream=true&header=true&height=435';
        $x=[
        'id'=>session()->get('id'),
        'name'=>session()->get('name'),
        'nic'=>session()->get('nic'),
        'avatar'=>session()->get('avatar'),
        'sss'=>$p,
        ];

        
        return view('home',compact('x'));
    }
    public function out()
    {
       Auth::logout();
       return redirect('/login');
    }
    
}
