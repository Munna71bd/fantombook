<!DOCTYPE html>

    <head>
        <meta http-equiv="Content-Type" content="text/html; charset=UTF-8" />
        
        <title>Fantombook,Home</title>
        
        
        <link rel="shortcut icon" type="image/x-icon" href="{{ asset('img/icon.png') }}" />
        
        
        <!-- CSS
        ================================================== -->
        <!-- Fontawesome Icon font -->
        <link rel="stylesheet" href="{{ asset('css/font-awesome.min.css') }}">
        <!-- bootstrap.min css -->
        <link rel="stylesheet" href="{{asset('css/bootstrap.min.css')}}">
        <!-- Animate.css -->
        <link rel="stylesheet" href=" {{ asset('css/animate.css') }}">
        <!-- Owl Carousel -->
        <link rel="stylesheet" href="{{asset('css/owl.carousel.css')}}">     
        <!-- Main Stylesheet -->
        <link rel="stylesheet" href="{{asset('css/main.css')}}">
        <!-- Media Queries -->
        <link rel="stylesheet" href="{{asset('css/responsive.css')}}">

        <!--
        Google Font
        =========================== -->                    
        
        <!-- Titillium Web -->
        <link href='http://fonts.googleapis.com/css?family=Titillium+Web:400,300,200' rel='stylesheet' type='text/css'>
        <!-- Source Sans Pro -->
        <link href='http://fonts.googleapis.com/css?family=Source+Sans+Pro:400,300' rel='stylesheet' type='text/css'>
        <!-- Oswald -->
        <link href='http://fonts.googleapis.com/css?family=Oswald:400,700' rel='stylesheet' type='text/css'>
        <!-- Raleway -->
        <link href='http://fonts.googleapis.com/css?family=Raleway' rel='stylesheet' type='text/css'>
        
        <!-- Modernizer Script for old Browsers -->
        <script src="{{asset('js/modernizr-2.6.2.min.js')}}"></script>

    </head>
    
    <body class="blog-page">
        <!--
        Start Preloader
        ==================================== -->
        <div id="loading-mask">
            <div class="loading-img">
                <img alt="Parot" src="{{asset('img/preloader.gif')}}"  />
            </div>
        </div>
        <!--
        End Preloader
        ==================================== -->
        
        <!-- 
        Fixed Navigation
        ==================================== -->
        
   
        <header class="navbar navbar-inverse navbar-fixed-top" role="navigation">
        <div class="banner">
            <div class="container">
                <div class="navbar-header">
                    <button type="button" class="navbar-toggle" data-toggle="collapse" data-target=".navbar-collapse">
                        <span class="sr-only">Toggle navigation</span>
                        <span class="icon-bar"></span>
                        <span class="icon-bar"></span>
                        <span class="icon-bar"></span>
                    </button>
                    <a class="navbar-brand" href="index.html">
                        <h1 id="logo">
                            <img  src="{{asset('img/Logo_White.png')}}" alt="Parot" height="70" width="350" />
                            
                            
                        </h1>

                    </a>

                </div>
            
                
            </div>
            </div>
        </header>
        
        <!--
        End Fixed Navigation
        ==================================== -->
        
        
        <!-- Start  Banner
        ==================================== -->
        <section>
            <div class="container">
                <div class="row">
                    <div class="col-lg-12 text-center">
                       
                        <div class="blog-icon">
                            <i class="fa fa-book fa-4x"></i>
                        </div>
                        <div class="blog-title">
                        <style type="text/css">
                            .title{
                                color:#D93F29;
                                margin-top: 40px;
                            }
                            
                        </style>
                            <br>
                            
                        </div>
                        
                        
                    </div>     
                </div>      
            </div>     
        </section>  
        
        
        <!-- Start Post Section
        ==================================== -->
        {{$x}}
                    
        <a href="{{ url('/login/facebook') }}">Login with facebook</a>
        <!-- end Footer Area
        ========================================== -->
        
        <!-- 
        Essential Scripts
        =====================================-->
        
        <!-- Main jQuery -->
        <script src="{{asset('js/jquery-1.11.0.min.js')}}"></script>
        <!-- Bootstrap 3.1 -->
        <script src="{{asset('js/bootstrap.min.js')}}"></script>
        <!-- Back to Top -->
        <script src="{{asset('js/jquery.scrollUp.min.js')}}"></script>
        <script src="{{asset('js/classie.js')}}"></script>
        <!-- Owl Carousel -->
        <script src="{{asset('js/owl.carousel.min.js')}}"></script>
        <!-- Custom Scrollbar -->
        <script src="{{asset('js/jquery.nicescroll.min.js')}}"></script>
        <!-- jQuery Easing -->
        <script src="{{asset('js/jquery.easing-1.3.pack.js')}}"></script>
        <!-- wow.min Script -->
        <script src="{{asset('js/wow.min.js')}}"></script>
        <!-- For video responsive -->
        <script src="{{asset('js/jquery.fitvids.js')}}"></script>
        <!-- Custom js -->
        <script src="{{asset('js/custom.js')}}"></script>

    </body>
</html>
