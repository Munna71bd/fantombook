<!DOCTYPE html>

    <head>
        <meta http-equiv="Content-Type" content="text/html; charset=UTF-8" />
        
        <title>Fantombook,Login</title>
        
        
        <link rel="shortcut icon" type="image/x-icon" href="<?php echo e(asset('img/icon.png')); ?>" />
        
        
        <!-- CSS
        ================================================== -->
        <!-- Fontawesome Icon font -->
        <link rel="stylesheet" href="<?php echo e(asset('css/font-awesome.min.css')); ?>">
        <!-- bootstrap.min css -->
        <link rel="stylesheet" href="<?php echo e(asset('css/bootstrap.min.css')); ?>">
        <!-- Animate.css -->
        <link rel="stylesheet" href=" <?php echo e(asset('css/animate.css')); ?>">
        <!-- Owl Carousel -->
        <link rel="stylesheet" href="<?php echo e(asset('css/owl.carousel.css')); ?>">     
        <!-- Main Stylesheet -->
        <link rel="stylesheet" href="<?php echo e(asset('css/main.css')); ?>">
        <!-- Media Queries -->
        <link rel="stylesheet" href="<?php echo e(asset('css/responsive.css')); ?>">

        <!--
        Google Font
        =========================== -->                    
        
        <!-- Titillium Web -->
        <link href='http://fonts.googleapis.com/css?family=Titillium+Web:400,300,200' rel='stylesheet' type='text/css'>
        <!-- Source Sans Pro -->
        <link href='http://fonts.googleapis.com/css?family=Source+Sans+Pro:400,300' rel='stylesheet' type='text/css'>
        <!-- Oswald -->
        <link href='http://fonts.googleapis.com/css?family=Oswald:400,700' rel='stylesheet' type='text/css'>
        <!-- Raleway -->
        <link href='http://fonts.googleapis.com/css?family=Raleway' rel='stylesheet' type='text/css'>
        
        <!-- Modernizer Script for old Browsers -->
        <script src="<?php echo e(asset('js/modernizr-2.6.2.min.js')); ?>"></script>

    </head>
    
    <body class="blog-page">
        <!--
        Start Preloader
        ==================================== -->
        <div id="loading-mask">
            <div class="loading-img">
                <img alt="Parot" src="<?php echo e(asset('img/preloader.gif')); ?>"  />
            </div>
        </div>
        <!--
        End Preloader
        ==================================== -->
        
        <!-- 
        Fixed Navigation
        ==================================== -->
        

        <header class="navbar navbar-inverse navbar-fixed-top" role="navigation">
        <div class="banner">
            <div class="container">
                <div class="navbar-header">
                    <button type="button" class="navbar-toggle" data-toggle="collapse" data-target=".navbar-collapse">
                        <span class="sr-only">Toggle navigation</span>
                        <span class="icon-bar"></span>
                        <span class="icon-bar"></span>
                        <span class="icon-bar"></span>
                    </button>
                    <a class="navbar-brand" href="index.html">
                        <h1 id="logo">
                            <img  src="<?php echo e(asset('img/Logo_White.png')); ?>" alt="Parot" height="70" width="350" />
                            
                            
                        </h1>

                    </a>

                </div>
            
                
            </div>
            </div>
        </header>
        
        <!--
        End Fixed Navigation
        ==================================== -->
        
        
        <!-- Start  Banner
        ==================================== -->
        <section>
            <div class="container">
                <div class="row">
                    <div class="col-lg-12 text-center">
                       
                        <div class="blog-icon">
                            <i class="fa fa-book fa-4x"></i>
                        </div>
                        <div class="blog-title">
                        <style type="text/css">
                            .title{
                                color:#D93F29;
                                margin-top: 40px;
                            }
                            
                        </style>
                            <br>
                            
                        </div>
                        
                        
                    </div>     
                </div>      
            </div>     
        </section>  
        
        
        <!-- Start Post Section
        ==================================== -->
        
                    
        <center >
        <a class="fb" href="<?php echo e(url('/login/facebook')); ?>"> <img src="<?php echo e(asset('img/fb.png')); ?>" width="500px" height="100px"></a>


        </center>
         <img src="<?php echo e(asset('img/laravel.jpg')); ?>" width="1095px" height="175px">
        <footer id="footer" class="bg-one">
            <div class="container">
                <div class="row wow fadeInUp" data-wow-duration="500ms">
                    <div class="col-lg-12">
                        
                        <!-- Footer Social Links -->
                        <div class="social-icon">
                            <ul>
                                <li><a href="#"><i class="fa fa-facebook"></i></a></li>
                                <li><a href="#"><i class="fa fa-twitter"></i></a></li>
                                <li><a href="#"><i class="fa fa-google-plus"></i></a></li>
                                <li><a href="#"><i class="fa fa-youtube"></i></a></li>
                                <li><a href="#"><i class="fa fa-linkedin"></i></a></li>
                                <li><a href="#"><i class="fa fa-dribbble"></i></a></li>
                                <li><a href="#"><i class="fa fa-pinterest"></i></a></li>
                            </ul>
                        </div>
                        <!--/. End Footer Social Links -->

                        <!-- copyright -->
                        <div class="copyright text-center">
                           
                            <p>Copyright &copy; 2017. All Rights Reserved To Mehedi Hasan Munna.</p>
                        </div>
                        <!-- /copyright -->
                        
                    </div> <!-- end col lg 12 -->
                </div> <!-- end row -->
            </div> <!-- end container -->
        </footer> <!-- end footer -->
        <!-- end Footer Area
        ========================================== -->
        
        <!-- 
        Essential Scripts
        =====================================-->
        
        <!-- Main jQuery -->
        <script src="<?php echo e(asset('js/jquery-1.11.0.min.js')); ?>"></script>
        <!-- Bootstrap 3.1 -->
        <script src="<?php echo e(asset('js/bootstrap.min.js')); ?>"></script>
        <!-- Back to Top -->
        <script src="<?php echo e(asset('js/jquery.scrollUp.min.js')); ?>"></script>
        <script src="<?php echo e(asset('js/classie.js')); ?>"></script>
        <!-- Owl Carousel -->
        <script src="<?php echo e(asset('js/owl.carousel.min.js')); ?>"></script>
        <!-- Custom Scrollbar -->
        <script src="<?php echo e(asset('js/jquery.nicescroll.min.js')); ?>"></script>
        <!-- jQuery Easing -->
        <script src="<?php echo e(asset('js/jquery.easing-1.3.pack.js')); ?>"></script>
        <!-- wow.min Script -->
        <script src="<?php echo e(asset('js/wow.min.js')); ?>"></script>
        <!-- For video responsive -->
        <script src="<?php echo e(asset('js/jquery.fitvids.js')); ?>"></script>
        <!-- Custom js -->
        <script src="<?php echo e(asset('js/custom.js')); ?>"></script>

    </body>
</html>
