
<!DOCTYPE html>
   
    <head>
        <meta http-equiv="Content-Type" content="text/html; charset=UTF-8" />
        
        <title>Fantombook,Home</title>
        
        
        <link rel="shortcut icon" type="image/x-icon" href="<?php echo e(asset('img/icon.png')); ?>" />
        
        
        <!-- CSS
        ================================================== -->
        <!-- Fontawesome Icon font -->
        <link rel="stylesheet" href="<?php echo e(asset('css/font-awesome.min.css')); ?>">
        <!-- bootstrap.min css -->
        <link rel="stylesheet" href="<?php echo e(asset('css/bootstrap.min.css')); ?>">
        <!-- Animate.css -->
        <link rel="stylesheet" href=" <?php echo e(asset('css/animate.css')); ?>">
        <!-- Owl Carousel -->
        <link rel="stylesheet" href="<?php echo e(asset('css/owl.carousel.css')); ?>">     
        <!-- Main Stylesheet -->
        <link rel="stylesheet" href="<?php echo e(asset('css/main.css')); ?>">
        <!-- Media Queries -->
        <link rel="stylesheet" href="<?php echo e(asset('css/responsive.css')); ?>">

        <!--
        Google Font
        =========================== -->                    
        
        <!-- Titillium Web -->
        <link href='http://fonts.googleapis.com/css?family=Titillium+Web:400,300,200' rel='stylesheet' type='text/css'>
        <!-- Source Sans Pro -->
        <link href='http://fonts.googleapis.com/css?family=Source+Sans+Pro:400,300' rel='stylesheet' type='text/css'>
        <!-- Oswald -->
        <link href='http://fonts.googleapis.com/css?family=Oswald:400,700' rel='stylesheet' type='text/css'>
        <!-- Raleway -->
        <link href='http://fonts.googleapis.com/css?family=Raleway' rel='stylesheet' type='text/css'>
        
        <!-- Modernizer Script for old Browsers -->
        <script src="<?php echo e(asset('js/modernizr-2.6.2.min.js')); ?>"></script>

    </head>
    
    <body class="blog-page">
        <!--
        Start Preloader
        ==================================== -->
        <div id="loading-mask">
            <div class="loading-img">
                <img alt="Parot" src="<?php echo e(asset('img/preloader.gif')); ?>"  />
            </div>
        </div>
        <!--
        End Preloader
        ==================================== -->
        
        <!-- 
        Fixed Navigation
        ==================================== -->
        

        <header class="navbar navbar-inverse navbar-fixed-top" role="navigation">
        <div class="banner">
            <div class="container">
                <div class="navbar-header">
                    <button type="button" class="navbar-toggle" data-toggle="collapse" data-target=".navbar-collapse">
                        <span class="sr-only">Toggle navigation</span>
                        <span class="icon-bar"></span>
                        <span class="icon-bar"></span>
                        <span class="icon-bar"></span>
                    </button>
                    <a class="navbar-brand" href="index.html">
                        <h1 id="logo">
                            <img  src="<?php echo e(asset('img/Logo_White.png')); ?>" alt="Parot" height="70" width="350" />
                            
                            
                        </h1>

                    </a>

                </div>
            
                <nav class="collapse navbar-collapse navbar-right" >
                    <ul id="nav" class="nav navbar-nav">
                        
                        <li><a href="<?php echo e(url('/logout')); ?>">Logout</a></li>
                    </ul>

                </nav><!-- /.navbar-collapse -->
            </div>
            </div>
        </header>
        
        <!--
        End Fixed Navigation
        ==================================== -->
        
        
        <!-- Start  Banner
        ==================================== -->
        <section>
            <div class="container">
                <div class="row">
                    <div class="col-lg-12 text-center">
                       
                        <div class="blog-icon">
                            <i class="fa fa-book fa-4x"></i>
                        </div>
                        <div class="blog-title">
                        <style type="text/css">
                            .title{
                                color:#D93F29;
                                margin-top: 40px;
                            }
                            
                        </style>
                            <br>
                            
                        </div>
                        
                        
                    </div>     
                </div>      
            </div>     
        </section>  
        
        
        <!-- Start Post Section
        ==================================== -->
        <section id="blog-page">
            <div class="container">
                <div class="row">
                   
                    <div id="blog-posts" class="col-md-8 col-sm-8">
                        <div class="post-item">
                           
                           <!-- Single Post -->
                            <article class="entry wow fadeInDown"  data-wow-duration="1000ms" data-wow-delay="300ms">                               
                                <div class="post-thumb">
                                    <a href="single-post.html">
                                    <center>
                                        
                                        </center>
                                    </a>
                                </div>
                                <div class="post-excerpt">
                                  <div class="news">  <h2 class="lbl">News feed</h2> </div>

                                </div>
                                
                            </article>
                            <!-- End Single Post -->
                            
                            
                            
                            
                            <div id="comments" class="comments-section">
                               
                                    
                                        <div class="comment-wrap">
                                
<iframe src="<?php echo e($x['sss']); ?>" scrolling="yes" frameborder="0" style="border:none; overflow:hidden; width:600px; height:430px; background: white; float:left; " allowtransparency="true">
    <p>This is facebook news feeed section</p>
</iframe>


                                        </div>


                                    </li>
                                </ol>
                            </div>

                           

                           
                            
                            
                           
                            <!-- End Single Post -->

                        </div>
                    </div>

                    
                    <!-- Widget Section -->
                    <div id="right-sidebar" class="col-md-4 col-sm-4">
                       

                        
                        <aside class="widget wow fadeInDown">
                            
                                
                            <div class="widget-content">
                                <!-- tab nav -->
                                <ul class="tab-post-nav clearfix">
                                    
                                </ul>
                                <!-- /tab nav -->
                                
                                <!-- tab content -->
                                <div class="tab-content">
                                    <article class="tab-pane active tab-post" id="popular">
                                        <div class="clearfix">
                                            <div class="tab-thumb">
                                             <h2>My Profile Information</h2>
                                             <img class="avatar" src="<?php echo e($x['avatar']); ?>" width="60px" height="70px"> <br>
                                          
                                              <label>Name:</label>  <label class="lbl"><?php echo e($x['name']); ?></label> <br>
                                              <label>ID:</label> <label class="lbl"><?php echo e($x['id']); ?></label> <br>
                                              <label>Email:</label><label class="lbl"><?php echo e($x['nic']); ?></label><br>
                                              <label>Gender:</label><br> <br>


                    <br>   


                                            </div>
                                       
                                          
                                            <div class="tab-excerpt">
                                            
                                                
                                            </div>
                                        </div>
                                        
                                    
                                        </div>


                                    </article>
                                    
                                            
                                    
                                </div>
                                <!-- /tab content -->
                                
                            </div>

                        </aside>
                        

                        
                        
                    </div>
                    <!-- End Widget Section -->



                </div>      <!-- End row -->
            </div>       <!-- End container -->
        </section>    <!-- End Section -->
        

 
        <!-- Start Footer Section
        ========================================== -->
        
        
        <!-- Back to Top
        ============================== -->
        <a href="#" id="scrollUp"><i class="fa fa-angle-up fa-2x"></i></a>
        
        <!-- end Footer Area
        ========================================== -->
        
        <!-- 
        Essential Scripts
        =====================================-->
        
        <!-- Main jQuery -->
        <script src="<?php echo e(asset('js/jquery-1.11.0.min.js')); ?>"></script>
        <!-- Bootstrap 3.1 -->
        <script src="<?php echo e(asset('js/bootstrap.min.js')); ?>"></script>
        <!-- Back to Top -->
        <script src="<?php echo e(asset('js/jquery.scrollUp.min.js')); ?>"></script>
        <script src="<?php echo e(asset('js/classie.js')); ?>"></script>
        <!-- Owl Carousel -->
        <script src="<?php echo e(asset('js/owl.carousel.min.js')); ?>"></script>
        <!-- Custom Scrollbar -->
        <script src="<?php echo e(asset('js/jquery.nicescroll.min.js')); ?>"></script>
        <!-- jQuery Easing -->
        <script src="<?php echo e(asset('js/jquery.easing-1.3.pack.js')); ?>"></script>
        <!-- wow.min Script -->
        <script src="<?php echo e(asset('js/wow.min.js')); ?>"></script>
        <!-- For video responsive -->
        <script src="<?php echo e(asset('js/jquery.fitvids.js')); ?>"></script>
        <!-- Custom js -->
        <script src="<?php echo e(asset('js/custom.js')); ?>"></script>


    </body>
</html>
